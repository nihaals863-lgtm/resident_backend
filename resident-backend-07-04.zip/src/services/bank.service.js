import prisma from '../config/prisma.js';
import * as paymentService from './payment.service.js';

export const getTransactions = async () => {
  return await prisma.bankTransaction.findMany({
    orderBy: { date: 'desc' }
  });
};

export const createTransaction = async (data) => {
  return await prisma.bankTransaction.create({
    data: {
      description: data.description,
      amount: data.amount,
      date: new Date(data.date),
      status: 'UNMATCHED'
    }
  });
};

export const uploadTransactions = async (txs) => {
  let importedCount = 0;
  let skippedCount = 0;

  for (const tx of txs) {
    const txDate = new Date(tx.date);
    
    // Check for existing transaction with same date, description and amount
    const existing = await prisma.bankTransaction.findFirst({
      where: {
        date: txDate,
        description: tx.description,
        amount: tx.amount,
      }
    });

    if (!existing) {
      await prisma.bankTransaction.create({
        data: {
          description: tx.description,
          amount: tx.amount,
          date: txDate,
          reference: tx.reference || null,
          status: 'UNMATCHED'
        }
      });
      importedCount++;
    } else {
      skippedCount++;
    }
  }

  return { success: true, importedCount, skippedCount };
};

export const matchTransaction = async (transactionId, residentId) => {
  const transaction = await prisma.bankTransaction.findUnique({
    where: { id: transactionId }
  });

  if (!transaction) throw new Error('Transaction not found');

  return await prisma.$transaction(async (tx) => {
    // 1. Record the payment
    const payment = await paymentService.recordPayment({
      residentId,
      amount: transaction.amount,
      date: transaction.date,
      method: 'Bank Transfer',
      note: `Matched from bank: ${transaction.description}`
    });

    // 2. Update transaction status
    await tx.bankTransaction.update({
      where: { id: transactionId },
      data: { status: 'MATCHED' }
    });

    // 3. Store alias for future auto-matching
    await tx.alias.upsert({
      where: { description: transaction.description },
      update: { residentId },
      create: { description: transaction.description, residentId }
    });

    return payment;
  });
};

export const deleteTransaction = async (id) => {
  return await prisma.bankTransaction.delete({
    where: { id }
  });
};

export const unmatchTransaction = async (id) => {
  const transaction = await prisma.bankTransaction.findUnique({
    where: { id },
    include: { 
      // We need to find the payment associated with this description/date/amount
      // This is a heuristic since we don't have a direct link in the schema yet
    }
  });

  if (!transaction) throw new Error('Transaction not found');

  // Find the most likely payment to reverse
  const payment = await prisma.payment.findFirst({
    where: {
      amount: transaction.amount,
      note: { contains: transaction.description }
    }
  });

  return await prisma.$transaction(async (tx) => {
    if (payment) {
      // Delete allocations first (CASCADE might handle this, but let's be safe)
      await tx.paymentAllocation.deleteMany({ where: { paymentId: payment.id } });
      await tx.payment.delete({ where: { id: payment.id } });
    }

    return await tx.bankTransaction.update({
      where: { id },
      data: { status: 'UNMATCHED' }
    });
  });
};

export const getSuggestedResident = async (description) => {
  // 1. Check exact alias
  const alias = await prisma.alias.findUnique({
    where: { description },
    include: { resident: true }
  });

  if (alias) return { resident: alias.resident, confidence: 'High', source: 'Alias' };

  // 2. Fuzzy match by name in description (Simplified)
  const residents = await prisma.resident.findMany({ include: { house: true } });
  for (const resident of residents) {
    if (description.toLowerCase().includes(resident.name.toLowerCase())) {
      return { resident, confidence: 'Medium', source: 'NameMatch' };
    }
    if (resident.house && description.toLowerCase().includes(resident.house.name.toLowerCase())) {
      return { resident, confidence: 'Medium', source: 'HouseMatch' };
    }
  }

  return null;
};

export const autoReconcile = async () => {
  const transactions = await prisma.bankTransaction.findMany({
    where: { status: 'UNMATCHED' }
  });

  let count = 0;
  for (const tx of transactions) {
    const suggestion = await getSuggestedResident(tx.description);
    
    // Only auto-reconcile if confidence is 'High' (Exact Alias Match)
    if (suggestion && suggestion.confidence === 'High') {
      await matchTransaction(tx.id, suggestion.resident.id);
      count++;
    }
  }

  return { success: true, count };
};
